VAIBHAV'S DREAM CITY
=====================

This is an offline Android WebView project.

Main web game:
app/src/main/assets/index.html

Android launcher:
app/src/main/java/com/vaibhav/dreamcity/MainActivity.kt

Important:
- No INTERNET permission is included.
- App opens index.html from local Android assets.
- Landscape fullscreen is enabled.
- Replace/update index.html and add local JS/CSS/3D assets inside:
  app/src/main/assets/

BUILD:
Open this project in Android Studio or another Android build environment.
Let Gradle sync, then build the APK.

If using Gemini:
"Complete/build this Android project exactly as provided. Keep the app offline.
Load app/src/main/assets/index.html in the WebView. Do not add external CDN or
internet dependencies. Build a release APK named VaibhavsDreamCity.apk."
